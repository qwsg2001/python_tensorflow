# AI-learns-to-play-the-dino-game

This is the source code for the dinosaur game AI
Just open the html file in your browser, no other software needed

Press C to toggle the clouds because they are useless
Press R to replay a champion from a given generation after the evolution is finished

Have Fun
